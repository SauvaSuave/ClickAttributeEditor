# -*- coding: utf-8 -*-
"""
ClickAttributeEditor — click a feature and type a value for a chosen field.

✅ Melhorias incluídas nesta versão:
- Identificação de feições com tolerância (mais fácil de “pegar” pontos)
- Seleção do campo a editar (e troca com SHIFT+clique)
- Desativa automaticamente quando você muda para outra ferramenta do QGIS
- Sem spam de notificações: só mostra aviso/erro quando der problema
- Ícone no botão da toolbar + texto do botão vira só o nome do campo (sem "Click edit")
"""

import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox
from qgis.PyQt.QtGui import QIcon, QCursor

from qgis.core import QgsMapLayerType, NULL
from qgis.gui import QgsMapToolIdentify


# ========= CONFIG =========
AUTO_START_EDITING = True   # inicia edição automaticamente se não estiver
AUTO_COMMIT = False         # True = commit a cada clique (pode ser lento)
WINDOW_TITLE = "Editar atributo (on-click)"
SEARCH_RADIUS_PX = 12       # aumente (15/20) se tiver dificuldade de clicar no ponto
ICON_FILENAME = "icon.png"  # arquivo do ícone dentro da pasta do plugin
# ==========================


def _is_numeric_field(field) -> bool:
    """Robusto: QgsField.isNumeric()"""
    try:
        return field.isNumeric()
    except Exception:
        return False


def _to_float_or_default(v, default=0.0) -> float:
    if v in (None, NULL, ""):
        return float(default)
    try:
        return float(v)
    except Exception:
        return float(default)


class ClickEditTool(QgsMapToolIdentify):
    """
    Usa QgsMapToolIdentify para permitir tolerância em pixels (mais parecido com a seleção do QGIS).
    """
    def __init__(self, iface, plugin):
        super().__init__(iface.mapCanvas())
        self.iface = iface
        self.plugin = plugin
        self.setCursor(QCursor(Qt.CrossCursor))

    def canvasReleaseEvent(self, event):
        layer = self.iface.activeLayer()
        if layer is None or (not layer.isValid()):
            self.iface.messageBar().pushWarning("ClickAttributeEditor", "Ative uma layer válida.")
            return

        if layer.type() != QgsMapLayerType.VectorLayer:
            self.iface.messageBar().pushWarning("ClickAttributeEditor", "A layer ativa precisa ser vetorial.")
            return

        # SHIFT + clique = trocar campo rapidamente
        if (event.modifiers() & Qt.ShiftModifier) or (not self.plugin.target_field):
            if not self.plugin.choose_field(layer):
                return  # cancelou

        idx = layer.fields().indexFromName(self.plugin.target_field)
        if idx < 0:
            self.iface.messageBar().pushWarning(
                "ClickAttributeEditor",
                f"Campo '{self.plugin.target_field}' não existe na layer ativa."
            )
            return

        # Identificar feição com tolerância (pixels)
        try:
            hits = self.identify(
                event.x(), event.y(),
                [layer],
                QgsMapToolIdentify.TopDownStopAtFirst,
                SEARCH_RADIUS_PX
            )
        except TypeError:
            # fallback para assinaturas antigas
            hits = self.identify(
                event.x(), event.y(),
                [layer],
                QgsMapToolIdentify.TopDownStopAtFirst
            )

        if not hits:
            # Só avisa quando não achar (isso é “erro operacional”)
            self.iface.messageBar().pushWarning(
                "ClickAttributeEditor",
                f"Nenhuma feição encontrada. Aumente SEARCH_RADIUS_PX (atual {SEARCH_RADIUS_PX})."
            )
            return

        feat = hits[0].mFeature

        # Garante modo de edição
        if not layer.isEditable():
            if AUTO_START_EDITING:
                if not layer.startEditing():
                    self.iface.messageBar().pushWarning("ClickAttributeEditor", "Não consegui iniciar edição.")
                    return
            else:
                self.iface.messageBar().pushWarning("ClickAttributeEditor", "Coloque a layer em edição.")
                return

        field_def = layer.fields()[idx]
        current_value = feat[self.plugin.target_field]

        # Popup
        if _is_numeric_field(field_def):
            start_val = _to_float_or_default(current_value, default=0.0)
            val, ok = QInputDialog.getDouble(
                self.iface.mainWindow(),
                WINDOW_TITLE,
                f"{self.plugin.target_field} (FID {feat.id()})",
                start_val,
                -1e18, 1e18,
                6
            )
            if not ok:
                return
            new_value = val
        else:
            text, ok = QInputDialog.getText(
                self.iface.mainWindow(),
                WINDOW_TITLE,
                f"{self.plugin.target_field} (FID {feat.id()})",
                text="" if current_value in (None, NULL) else str(current_value)
            )
            if not ok:
                return
            new_value = text

        # Atualiza
        if not layer.changeAttributeValue(feat.id(), idx, new_value):
            QMessageBox.warning(self.iface.mainWindow(), "ClickAttributeEditor", "Falha ao atualizar o atributo.")
            return

        layer.triggerRepaint()

        if AUTO_COMMIT:
            if not layer.commitChanges():
                layer.rollBack()
                QMessageBox.warning(self.iface.mainWindow(), "ClickAttributeEditor", "Falha no commit. Desfeito.")
                return
            layer.startEditing()

        # ✅ Sem pushSuccess aqui (sem spam)


class ClickAttributeEditor:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.action_choose = None
        self.tool = None
        self.prev_tool = None

        self.target_field = None
        self.icon = QIcon()

    # --------- auto-desativar ao trocar de ferramenta ----------
    def _on_map_tool_set(self, new_tool, old_tool):
        # Se o plugin estava ativo e você mudou para outra ferramenta, desativa o botão
        if self.action and self.action.isChecked() and new_tool is not self.tool:
            self.action.blockSignals(True)
            self.action.setChecked(False)
            self.action.blockSignals(False)
            self.prev_tool = None
            # Mensagem opcional (uma só, quando troca)
            self.iface.messageBar().pushInfo("ClickAttributeEditor", "Ferramenta desativada (você trocou de tool).")

    def initGui(self):
        # Carrega ícone da pasta do plugin (icon.png)
        icon_path = os.path.join(os.path.dirname(__file__), ICON_FILENAME)
        if os.path.exists(icon_path):
            self.icon = QIcon(icon_path)

        # Botão principal (toolbar)
        # Texto vai ser SOMENTE o nome do campo (sem "Click edit")
        self.action = QAction(self.icon, "", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.setToolTip("ClickAttributeEditor: clique na feição para editar um campo (SHIFT+clique troca o campo).")
        self.action.triggered.connect(self.toggle_tool)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("ClickAttributeEditor", self.action)

        # Ação secundária no menu (trocar campo sem SHIFT)
        self.action_choose = QAction(self.icon, "Set target field…", self.iface.mainWindow())
        self.action_choose.triggered.connect(self.choose_field_from_active_layer)
        self.iface.addPluginToMenu("ClickAttributeEditor", self.action_choose)

        self.tool = ClickEditTool(self.iface, self)

        # Conecta evento para auto-desativar quando trocar de ferramenta
        self.iface.mapCanvas().mapToolSet.connect(self._on_map_tool_set)

        # Se já tiver layer ativa vetorial, pede o campo uma vez (sem spam)
        layer = self.iface.activeLayer()
        if layer and layer.isValid() and layer.type() == QgsMapLayerType.VectorLayer:
            # não obriga, mas ajuda: se quiser escolher só quando clicar, pode remover isso
            self.choose_field(layer)

    def unload(self):
        # Desconecta signal
        try:
            self.iface.mapCanvas().mapToolSet.disconnect(self._on_map_tool_set)
        except Exception:
            pass

        # Remove ações do menu/toolbar
        for act in (self.action, self.action_choose):
            if act:
                try:
                    self.iface.removePluginMenu("ClickAttributeEditor", act)
                except Exception:
                    pass
        if self.action:
            try:
                self.iface.removeToolBarIcon(self.action)
            except Exception:
                pass

    def toggle_tool(self, checked):
        canvas = self.iface.mapCanvas()
        if checked:
            self.prev_tool = canvas.mapTool()
            canvas.setMapTool(self.tool)
            # Sem mensagem aqui (para não “poluir”)
        else:
            if self.prev_tool:
                canvas.setMapTool(self.prev_tool)
            # Sem mensagem aqui também (quem avisa é o mapToolSet quando troca)

    def choose_field_from_active_layer(self):
        layer = self.iface.activeLayer()
        if not layer or (not layer.isValid()) or layer.type() != QgsMapLayerType.VectorLayer:
            self.iface.messageBar().pushWarning("ClickAttributeEditor", "Ative uma layer vetorial primeiro.")
            return
        self.choose_field(layer)

    def choose_field(self, layer) -> bool:
        fields = [f.name() for f in layer.fields()]
        if not fields:
            self.iface.messageBar().pushWarning("ClickAttributeEditor", "Layer sem campos.")
            return False

        current = self.target_field if self.target_field in fields else fields[0]
        choice, ok = QInputDialog.getItem(
            self.iface.mainWindow(),
            "Escolher campo",
            "Qual campo editar on-click? (SHIFT+clique troca rápido)",
            fields,
            fields.index(current),
            False
        )
        if not ok or not choice:
            return False

        self.target_field = choice

        # ✅ Texto do botão = só o campo (ícone já mostra “função”)
        if self.action:
            self.action.setText(self.target_field)

        return True
