def classFactory(iface):
    from .click_attribute_editor import ClickAttributeEditor
    return ClickAttributeEditor(iface)
